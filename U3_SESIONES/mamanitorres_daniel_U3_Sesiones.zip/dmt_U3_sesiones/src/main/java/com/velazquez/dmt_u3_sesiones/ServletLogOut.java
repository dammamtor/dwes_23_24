package com.velazquez.dmt_u3_sesiones;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

@WebServlet("/ServletLogOut")
public class ServletLogOut extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(ServletLogOut.class);
    public void init() {
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        if(!session.isNew() && (boolean) session.getAttribute("LOGUEADO")) {
            logger.info("CERRANDO SESION EN SERVLET LOGOUT");
            session.invalidate();
            resp.sendRedirect(req.getContextPath());
        } else {
            logger.error("NO PUEDES CERRAR SESION SIN HABERTE REGISTRADO");
            resp.sendRedirect(req.getContextPath());
        }
    }
}