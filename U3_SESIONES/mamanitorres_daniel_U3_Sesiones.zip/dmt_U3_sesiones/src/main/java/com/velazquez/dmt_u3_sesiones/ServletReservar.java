package com.velazquez.dmt_u3_sesiones;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;
import model.ReservaBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.regex.Pattern;

@WebServlet("/ServletReservar")
public class ServletReservar extends HttpServlet {
    private static final String regexPattern = "^\\d{1,2}/\\d{1,2}/\\d{2,4}$";
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(regexPattern);

    private static final String regexNumeroPersonas = "^[0-9]+$";
    private static final Pattern NUMERO_PERSONAS_PATTERN = Pattern.compile(regexNumeroPersonas);

    static final Logger logger = LoggerFactory.getLogger(ServletReservar.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.info("REALIZANDO GET DE SERVLET RESERVAR");
        HttpSession session = req.getSession();
        if (!session.isNew() && session.getAttribute("LOGUEADO")!= null && (boolean)session.getAttribute("LOGUEADO")) {
            logger.info("COMO ESTAS EN ESTE GET PUES OBVIO QUE INICIASTE SESION");
            logger.info("TOMA JSP DEL FORMULARIO PARA RESERVA");
            req.getRequestDispatcher("WEB-INF/view/formularioReserva.jsp").forward(req, resp);
        } else {
            logger.warn("NO ESTAS LOGUEADO");
            session.invalidate();
            resp.sendRedirect(req.getContextPath());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();

        if (!session.isNew() && (boolean)session.getAttribute("LOGUEADO") ) {
            logger.info("REALIZANDO EL POST DE SERVLET RESERVAR");

            Enumeration<String> parametros = req.getParameterNames();
            while (parametros.hasMoreElements()) {
                String param = parametros.nextElement();
                logger.info(param+": " + req.getParameter(param));
            }
            String[] seleccion = req.getParameterValues("servicios");
            if (seleccion == null || seleccion.length == 0) {
                logger.error("Debe seleccionar al menos un servicio.");
                resp.sendRedirect(req.getContextPath() + "/ServletReservar");
                return;
            }
            logger.info("El valor de Servicios es: "+ Arrays.toString(seleccion));

            String fechaInicio = req.getParameter("fechainicio");
            if (!PASSWORD_PATTERN.matcher(fechaInicio).matches()){
                logger.error("Fecha de inicio no valida");
                resp.sendRedirect(req.getContextPath() + "/ServletReservar");
                return;
            }

            String fechaFin = req.getParameter("fechafin");
            if (!PASSWORD_PATTERN.matcher(fechaFin).matches()){
                logger.error("Fecha de fin no valida");
                resp.sendRedirect(req.getContextPath() + "/ServletReservar");
                return;
            }

            //illo que esto es para comprobar que las fechas no formen paradojas temporales
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date fechaInicioDate;
            Date fechaFinDate;

            try {
                fechaInicioDate = sdf.parse(fechaInicio);
                fechaFinDate = sdf.parse(fechaFin);
                //hacemos esto para pasar los string a date

                if (fechaInicioDate.after(fechaFinDate)) {
                    logger.error("La fecha de inicio debe ser anterior a la fecha de fin.");
                    resp.sendRedirect(req.getContextPath() + "/ServletReservar");
                    return;
                }
            } catch (ParseException e) {
                logger.error("Error al parsear las fechas.");
                resp.sendRedirect(req.getContextPath() + "/ServletReservar");
                return;
            }

            String numeroPersonasST = req.getParameter("numeropersonas");
            if (!NUMERO_PERSONAS_PATTERN.matcher(numeroPersonasST).matches()){
                logger.error("NO SE ACEPTAN NUMEROS");
                resp.sendRedirect(req.getContextPath() + "/ServletReservar");
                return;
            }
            int numeropersonas = Integer.parseInt(numeroPersonasST);
            ReservaBean reserva = new ReservaBean();
            reserva.setFechaInicio(req.getParameter("fechainicio"));
            reserva.setFechaFin(req.getParameter("fechafin"));
            reserva.setNumeroPersonas(numeropersonas);
            ArrayList<String> servicios = new ArrayList<>(Arrays.asList(seleccion));

            reserva.setServicios(servicios);
            logger.info(reserva.toString());

            // Almacenar en la sesión antes de redirigir
            session.setAttribute("reservaBean", reserva);

            resp.sendRedirect(req.getContextPath()+"/ServletConfirmar");
        } else {
            logger.error("NO SE HA RECIBIDO LA SESION ADECUADA");
            resp.sendRedirect(req.getContextPath());
        }
    }
}
