package com.velazquez.dmt_u3_sesiones;

import java.io.*;
import java.util.regex.Pattern;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebServlet(name = "ServletInicio")
public class ServletInicio extends HttpServlet {
    private static final String regexPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(regexPattern);
    static final Logger logger = LoggerFactory.getLogger(ServletInicio.class);

    private String message;

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        logger.info("Realizando peticion GET de SERVLET INICIO");
        request.getRequestDispatcher("WEB-INF/view/loginReserva.jsp").forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.info("Ejecutando el POST de SERVLET INICIO");

        String usuario = req.getParameter("usuario");
        String contrasena = req.getParameter("contrasena");
        String confirmarContrasena = req.getParameter("confirmarpassword");
        String email = req.getParameter("email");

        if (req.getParameter("boton-registrar").equals("Registrar")){
            HttpSession session = req.getSession();
            session.setAttribute("LOGUEADO", true);
            session.setAttribute("USUARIO", usuario);
            logger.info("Valor del boton: " + req.getParameter("boton-registrar"));

            if (!PASSWORD_PATTERN.matcher(contrasena).matches() || !PASSWORD_PATTERN.matcher(confirmarContrasena).matches()){
                logger.error("CONTRASEÑAS INVALIDAS");
                resp.sendRedirect(req.getContextPath());
                return;
            }

            if (!contrasena.equals(confirmarContrasena)) {
                logger.warn("La contraseña y la confirmación de contraseña no coinciden");
                resp.sendRedirect(req.getContextPath());
                return;
            }
            logger.info("Usuario registrado: " + usuario);
            logger.info("Email registrado: " + email);
            resp.sendRedirect(req.getContextPath() + "/ServletReservar");
        } else {
            logger.error("Parametro nulo");
        }
    }

    public void destroy() {
    }
}