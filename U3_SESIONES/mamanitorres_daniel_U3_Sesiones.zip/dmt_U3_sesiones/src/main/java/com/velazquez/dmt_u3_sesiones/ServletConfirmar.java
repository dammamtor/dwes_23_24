package com.velazquez.dmt_u3_sesiones;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

@WebServlet("/ServletConfirmar")
public class ServletConfirmar extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(ServletConfirmar.class);
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.info("REALIZANDO EL GET DE SERVLET CONFIRMAR");
        HttpSession session = req.getSession();
        if (!session.isNew() && session.getAttribute("LOGUEADO")!= null && (boolean)session.getAttribute("LOGUEADO") ) {
            // Verificar si el objeto reservaBean está presente en la sesión
            if (session.getAttribute("reservaBean") != null) {
                logger.info("RESERVA CONFIRMADA");
                logger.info(session.getAttribute("reservaBean").toString());
                req.getRequestDispatcher("WEB-INF/view/reserva.jsp").forward(req, resp);
            } else {
                // Si no hay reservaBean en la sesión, redirigir al servlet de reserva
                logger.warn("Intento de acceso a ServletConfirmar sin completar la reserva");
                resp.sendRedirect(req.getContextPath() + "/ServletReservar");
            }
        } else {
            logger.warn("NO ESTAS LOGUEADO");
            session.invalidate();
            resp.sendRedirect(req.getContextPath());
        }
    }
}
