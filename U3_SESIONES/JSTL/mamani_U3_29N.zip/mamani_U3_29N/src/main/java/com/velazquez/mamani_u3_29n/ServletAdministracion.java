package com.velazquez.mamani_u3_29n;

import com.velazquez.mamani_u3_29n.dao.DAOProductImpl;
import com.velazquez.mamani_u3_29n.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;

public class ServletAdministracion extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        DAOProductImpl daoImpl = new DAOProductImpl();

        ArrayList<Product> listaProductos = daoImpl.getAllProducts();

        request.setAttribute("productos", listaProductos);

        request.getRequestDispatcher("/WEB-INF/view/admin/index.jsp").forward(request, response);
    }
}
