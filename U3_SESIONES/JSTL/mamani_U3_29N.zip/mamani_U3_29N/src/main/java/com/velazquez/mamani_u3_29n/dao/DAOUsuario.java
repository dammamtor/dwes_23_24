package com.velazquez.mamani_u3_29n.dao;

import com.velazquez.mamani_u3_29n.model.Usuario;

public interface DAOUsuario {

  public Usuario getUsuario(String nombre);

  public boolean registerUsuario(Usuario usuario);
}
