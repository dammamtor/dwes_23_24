package com.velazquez.mamani_u3_29n.dao;

import com.velazquez.mamani_u3_29n.bd.DBConnection;
import com.velazquez.mamani_u3_29n.model.Oficinas;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOOficinasImpl implements DAOOficina{
    public DAOOficinasImpl() {
    }
    @Override
    public Oficinas getOficinas(String ciudad) {
        Oficinas oficina = null;
        try {
            String sql = "SELECT * FROM offices WHERE city=?";
            PreparedStatement statement = DBConnection.getConnection().prepareStatement(sql);
            statement.setString(1, ciudad);

            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                oficina = new Oficinas();
                oficina.setOfficeCode(rs.getString("officeCode"));
                oficina.setCity(rs.getString("city"));
                oficina.setPhone(rs.getString("phone"));
                oficina.setAddressLine1(rs.getString("addressLine1"));
                oficina.setAddressLine2(rs.getString("addressLine2"));
                oficina.setState(rs.getString("state"));
                oficina.setCountry(rs.getString("country"));
                oficina.setPostalCode(rs.getString("postalCode"));
                oficina.setTerritory(rs.getString("territory"));
            }
            DBConnection.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return oficina;
    }

}
