package com.velazquez.mamani_u3_29n;

import java.io.*;

import com.velazquez.mamani_u3_29n.dao.DAOUsuarioImpl;
import com.velazquez.mamani_u3_29n.model.Usuario;
import com.velazquez.mamani_u3_29n.utils.PasswordHashGenerator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServletRegistrar extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(ServletRegistrar.class);
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("HORA DE REGISTRAR");
        request.getRequestDispatcher("/WEB-INF/view/register.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Vamos a obtener los campos del formulario
        logger.info("OBTENIENDO DATOS DEL REGISTRO");
        String usuario = request.getParameter("usuario");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");

        DAOUsuarioImpl dao = new DAOUsuarioImpl();

        // Comprobamos que los parámetros no son nulos
        if (usuario != null && email != null && password != null) {
            if (dao.getUsuario(usuario) != null) {

                request.setAttribute("error", "Usuario existente");
                doGet(request, response);
                return;
            } else {
                password = PasswordHashGenerator.hashPassword(password);

                // Modificar el rol a "admin" para el usuario administrador
                String role = "usuario";
                if ("admin".equals(usuario)) {
                    role = "admin";
                }

                Usuario user = new Usuario(usuario, password, email, role, firstName, lastName);
                dao.registerUsuario(user);
            }
        }
        response.sendRedirect(request.getContextPath());
    }
}
