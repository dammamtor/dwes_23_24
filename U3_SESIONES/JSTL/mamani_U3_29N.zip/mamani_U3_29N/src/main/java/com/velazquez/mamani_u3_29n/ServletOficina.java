package com.velazquez.mamani_u3_29n;

import com.velazquez.mamani_u3_29n.dao.DAOOficina;
import com.velazquez.mamani_u3_29n.dao.DAOOficinasImpl;
import com.velazquez.mamani_u3_29n.model.Oficinas;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class ServletOficina extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(ServletOficina.class);

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("HORA DE DESPLEGAR EL SELECT DE CIUDADES");
        request.getRequestDispatcher("/WEB-INF/view/buscarOficinas.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recogemos los datos del formulario
        String oficinaSeleccionada = request.getParameter("oficinas");

        // Puedes imprimir o registrar la información para verificar que se ha recogido correctamente
        logger.info("Oficina seleccionada: {}", oficinaSeleccionada);

        if (oficinaSeleccionada != null) {
            DAOOficinasImpl dao = new DAOOficinasImpl();
            Oficinas office = dao.getOficinas(oficinaSeleccionada);
            logger.info(office.getOfficeCode());
            logger.info(office.getCity());
            logger.info(office.getPhone());
            logger.info(office.getAddressLine1());
            logger.info(office.getAddressLine2());
            logger.info(office.getState());
            logger.info(office.getCountry());
            logger.info(office.getPostalCode());
            logger.info(office.getTerritory());

            HttpSession sesion = request.getSession();
            sesion.setAttribute("officeCode", office.getOfficeCode());
            sesion.setAttribute("city", office.getCity());
            sesion.setAttribute("phone", office.getPhone());
            sesion.setAttribute("addressLine1", office.getAddressLine1());
            sesion.setAttribute("addressLine2", office.getAddressLine2());
            sesion.setAttribute("state", office.getState());
            sesion.setAttribute("country", office.getCountry());
            sesion.setAttribute("postalCode", office.getPostalCode());
            sesion.setAttribute("territory", office.getTerritory());
            request.getRequestDispatcher("/WEB-INF/view/buscarOficinas.jsp").forward(request, response);
        }
    }
}
