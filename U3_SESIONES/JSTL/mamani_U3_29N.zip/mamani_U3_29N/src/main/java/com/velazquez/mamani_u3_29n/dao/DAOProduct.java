package com.velazquez.mamani_u3_29n.dao;

import com.velazquez.mamani_u3_29n.model.Product;

import java.util.ArrayList;

public interface DAOProduct {

  Product getProduct(String productName);

  ArrayList<Product> getAllProducts();

  Product getProductByCode(String code);

  ArrayList<Product> getProductSearch(String searchTerm);
}
