package com.velazquez.examenrecuperacionmamani.controller;
import com.velazquez.examenrecuperacionmamani.dao.DAOUsuarioImpl;
import com.velazquez.examenrecuperacionmamani.model.Usuario;
import com.velazquez.examenrecuperacionmamani.utils.PasswordHashGenerator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class RegistrarServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(RegistrarServlet.class);
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("ESTAS EN EL DO GET DEL REGISTRAR SERVLET");
        request.getRequestDispatcher("/WEB-INF/view/register.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("ESTAS EN EL DO POST DE REGISTRAR SERVLET");
        // Vamos a obtener los campos del formulario
        String usuario = request.getParameter("usuario");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        DAOUsuarioImpl dao = new DAOUsuarioImpl();

        // Comprobamos que los parámetros no son nulos
        if (usuario != null && email != null && password != null) {
            if (dao.getUsuario(usuario) != null) {

                request.setAttribute("error", "Usuario existente");
                doGet(request, response);
                return;
            } else {
                password = PasswordHashGenerator.hashPassword(password);
                Usuario user = new Usuario(usuario, password, email, "usuario");

                // Verificar si el usuario recién creado tiene el nombre de usuario "admin"
                if ("admin".equalsIgnoreCase(usuario)) {
                    user.setRole("admin"); // Asignar el rol de "admin" al usuario
                }

                logger.info("CREANDO NUEVO USUARIO");
                dao.registerUsuario(user);
            }
        }
        response.sendRedirect(request.getContextPath());
    }
}
