package com.velazquez.examenrecuperacionmamani.controller;

import com.velazquez.examenrecuperacionmamani.dao.DAOProductImpl;
import com.velazquez.examenrecuperacionmamani.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;

public class ProductLineReportServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(ProductLineReportServlet.class);
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, IOException {
        String productLine = request.getParameter("productLine");
        logger.info("PARAMETER PRODUCT LINE: " +  productLine);
        DAOProductImpl productDAO = new DAOProductImpl();
        List<Product> products = productDAO.getProductsByProductLine(productLine);

        int numberOfProducts = products.size();
        int totalStock = products.stream().mapToInt(Product::getQuantityInStock).sum();

        request.setAttribute("productLine", productLine);
        request.setAttribute("numberOfProducts", numberOfProducts);
        request.setAttribute("totalStock", totalStock);

        // Redirigir a la página de informe
        request.getRequestDispatcher("/WEB-INF/view/productLine.jsp").forward(request, response);
    }
}
