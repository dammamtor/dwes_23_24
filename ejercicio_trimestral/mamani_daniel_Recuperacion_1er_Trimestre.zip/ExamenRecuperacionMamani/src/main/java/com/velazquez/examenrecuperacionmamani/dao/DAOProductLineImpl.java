package com.velazquez.examenrecuperacionmamani.dao;

import com.velazquez.examenrecuperacionmamani.bd.PoolDB;
import com.velazquez.examenrecuperacionmamani.model.ProductLine;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DAOProductLineImpl implements DAOProductLine{
    static final Logger logger = LoggerFactory.getLogger(DAOProductLineImpl.class);

    public DAOProductLineImpl() {
    }

    @Override
    public ProductLine getProductLine(String productLine) {
        ProductLine categoria = null;
        Connection con = null;

        try {
            String sql = "SELECT * FROM productlines WHERE productLine = ?";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            // Como el campo de búsqueda es la clave solo debería obtener un resultado
            // si no es así estaremos machacando cada vez el valor de productLine
            while (rs.next()) {
                categoria = new ProductLine();

                categoria.setProductLine(rs.getString("productLine"));
                categoria.setTextDescription(rs.getString("textDescription"));
            }

        } catch (SQLException e) {
            logger.error(e.getMessage());
            logger.error(Arrays.toString(e.getStackTrace()));
        }
        return categoria;
    }

    @Override
    public ArrayList<ProductLine> getAll() {
        ArrayList<ProductLine> categoriasList = new ArrayList<>();
        ProductLine categoria;
        Connection con = null;

        try {
            String sql = "SELECT * FROM productlines";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {

                categoria = new ProductLine();
                categoria.setProductLine(rs.getString("productLine"));
                categoria.setTextDescription(rs.getString("textDescription"));
                categoria.setHtmlDescription(rs.getString("htmlDescription"));

                categoriasList.add(categoria);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            logger.error(Arrays.toString(e.getStackTrace()));
        }
        return categoriasList;
    }

    @Override
    public boolean updateProductLine(ProductLine productLine) {
        Connection con = null;
        int resultado = 0;
        try {
            String sql =
                    "UPDATE productlines productLine=?, textDescription=?, htmlDescription=? SET WHERE productLine = ?";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, productLine.getProductLine());
            statement.setString(2, productLine.getTextDescription());
            statement.setString(3, productLine.getHtmlDescription());
            statement.setString(4, productLine.getProductLine());

            resultado = statement.executeUpdate(sql);

        } catch (SQLException e) {
            logger.error(e.getMessage());
            logger.error(Arrays.toString(e.getStackTrace()));
        }
        return (resultado != 0);
    }

    @Override
    public boolean removeProductLine(String productLine) {
        int resultado = 0;
        Connection con = null;
        try {
            String sql = "DELETE FROM productlines WHERE productLine = ?";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, productLine);

            resultado = statement.executeUpdate(sql);

        } catch (SQLException e) {
            logger.error(e.getMessage());
            logger.error(Arrays.toString(e.getStackTrace()));
        }
        return (resultado != 0);
    }

    @Override
    public boolean createProductLine(ProductLine productLine) {
        int resultado = 0;
        Connection con = null;
        try {
            String sql = "INSERT INTO productlines VALUES(?,?,?,null)";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, productLine.getProductLine());
            statement.setString(2, productLine.getTextDescription());
            statement.setString(3, productLine.getHtmlDescription());

            resultado = statement.executeUpdate();

        } catch (SQLException e) {
            logger.error(e.getMessage());
            logger.error(Arrays.toString(e.getStackTrace()));
        }
        return (resultado != 0);
    }
}
