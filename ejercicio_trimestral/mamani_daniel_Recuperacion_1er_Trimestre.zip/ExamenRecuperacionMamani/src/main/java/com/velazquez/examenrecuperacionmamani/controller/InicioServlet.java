package com.velazquez.examenrecuperacionmamani.controller;

import com.velazquez.examenrecuperacionmamani.dao.DAOProductLineImpl;
import com.velazquez.examenrecuperacionmamani.model.ProductLine;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;

public class InicioServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(InicioServlet.class);

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        logger.info("ESTAS EN EL GET DE INICIO SERVLET");
        // Obtengo desde la base de datos y través del DAO todos los productlines
        DAOProductLineImpl dao = new DAOProductLineImpl();
        ArrayList<ProductLine> categorias = dao.getAll();

        request.setAttribute("categorias", categorias);
        request.getRequestDispatcher("/WEB-INF/view/home.jsp").forward(request, response);
    }
}