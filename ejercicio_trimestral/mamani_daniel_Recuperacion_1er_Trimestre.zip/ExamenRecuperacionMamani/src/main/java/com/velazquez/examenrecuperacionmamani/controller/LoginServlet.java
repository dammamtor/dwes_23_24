package com.velazquez.examenrecuperacionmamani.controller;

import java.io.*;

import com.velazquez.examenrecuperacionmamani.dao.DAOUsuarioImpl;
import com.velazquez.examenrecuperacionmamani.model.Usuario;
import com.velazquez.examenrecuperacionmamani.utils.PasswordHashGenerator;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoginServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(LoginServlet.class);
    private static final long serialVersionUID = 1L;


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("ESTAS EN EL DO GET DE LOGIN SERVLET");
        request.getRequestDispatcher("/WEB-INF/view/index.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("LLEGASTE AL DO POST DE LOGIN SERVLET");
        // Comprobamos si tenemos los datos de la petición del formulario
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        logger.info("Usuario: " + email + ", Password: " + password);
        if (email != null && password != null) {

            DAOUsuarioImpl dao = new DAOUsuarioImpl();

            Usuario user = dao.getUsuario(email);


            if (user != null) {
                logger.info("Usuario encontrado: " + user.getUsuario());
                logger.info("Password DB: " + user.getPassword());
                logger.info("Password Request: " + password);
                if (PasswordHashGenerator.checkPassword(password, user.getPassword())) {

                    HttpSession sesion = request.getSession();

                    sesion.setAttribute("usuario", user.getUsuario());
                    sesion.setAttribute("email", user.getEmail());
                    sesion.setAttribute("role", user.getRole());

                    if ("admin".equals(user.getRole())) {
                        response.sendRedirect("Admin/Inicio");
                    } else {
                        response.sendRedirect("home");
                    }
                } else {
                    request.setAttribute("error", "login inválido");
                    doGet(request, response);
                    return;
                }
            } else {
                request.setAttribute("error", "Usuario no existente");
                doGet(request, response);
            }
        }
    }
}