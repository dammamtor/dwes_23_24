package com.velazquez.examenrecuperacionmamani.controller;

import com.velazquez.examenrecuperacionmamani.dao.DAOProductLineImpl;
import com.velazquez.examenrecuperacionmamani.model.ProductLine;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;

public class AdminInicioServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(AdminInicioServlet.class);
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, IOException {
        logger.info("LLEGASTE AL ADMIN SERVLET");
        // Obtengo desde la base de datos y través del DAO todos los productlines
        DAOProductLineImpl dao = new DAOProductLineImpl();
        ArrayList<ProductLine> categorias = dao.getAll();

        request.setAttribute("categorias", categorias);
        request.getRequestDispatcher("/WEB-INF/view/admin/admin.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
