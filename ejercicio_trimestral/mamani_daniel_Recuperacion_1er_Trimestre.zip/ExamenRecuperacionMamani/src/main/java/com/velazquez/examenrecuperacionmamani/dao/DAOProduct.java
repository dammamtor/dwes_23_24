package com.velazquez.examenrecuperacionmamani.dao;

import com.velazquez.examenrecuperacionmamani.model.Product;

import java.util.List;

public interface DAOProduct {
    List<Product> getProductsByProductLine(String productLine);
}
