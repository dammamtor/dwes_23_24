package com.velazquez.examenrecuperacionmamani.dao;

import com.velazquez.examenrecuperacionmamani.model.Usuario;

public interface DAOUsuario {
    public Usuario getUsuario(String nombre);

    public boolean registerUsuario(Usuario usuario);
}
