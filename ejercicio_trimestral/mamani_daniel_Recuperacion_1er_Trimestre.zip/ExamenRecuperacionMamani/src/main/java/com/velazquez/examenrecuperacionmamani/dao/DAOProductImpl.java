package com.velazquez.examenrecuperacionmamani.dao;

import com.velazquez.examenrecuperacionmamani.bd.PoolDB;
import com.velazquez.examenrecuperacionmamani.model.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOProductImpl implements DAOProduct {
    @Override
    public List<Product> getProductsByProductLine(String productLine) {
        List<Product> products = new ArrayList<>();
        Connection con = null;
        try {
            String sql = "SELECT * FROM products WHERE productLine = ?";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, productLine);

            ResultSet rs = statement.executeQuery();


            while (rs.next()) {
                // Mapear los resultados a objetos Product
                Product product = new Product(
                        rs.getString("productName"),
                        rs.getString("productCode"),
                        rs.getString("productLine"),
                        rs.getString("productScale"),
                        rs.getString("productVendor"),
                        rs.getString("productDescription"),
                        rs.getInt("quantityInStock"),
                        rs.getDouble("buyPrice"),
                        rs.getDouble("msrp")
                );
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo adecuado de excepciones en producción
        }

        return products;
    }
}

