package com.velazquez.examenrecuperacionmamani.controller;

import com.velazquez.examenrecuperacionmamani.dao.DAOProductLineImpl;
import com.velazquez.examenrecuperacionmamani.model.ProductLine;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class AddProductLineServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(AddProductLineServlet.class);

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("ESTAS EN EL DO GET DE AÑADIR CATEGORIA");
        request.getRequestDispatcher("/WEB-INF/view/admin/create.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("ESTÁS EN EL DO POST DE AGREGAR CATEGORÍA");

        String categoria = request.getParameter("productLine");
        String texto = request.getParameter("textDescription");

        if (categoria != null && !categoria.trim().isEmpty() && texto != null && !texto.trim().isEmpty()) {
            DAOProductLineImpl dao = new DAOProductLineImpl();
            if (dao.getProductLine(categoria) == null) {
                ProductLine pl = new ProductLine(categoria, texto);
                dao.createProductLine(pl);
                response.sendRedirect("Inicio");
            } else {
                request.setAttribute("error", "Categoría ya existente");
                request.setAttribute("categoria", categoria);
                request.setAttribute("texto", texto);
                doGet(request, response);
            }
        } else {
            request.setAttribute("error", "Categoría y texto no pueden estar vacíos");
            request.setAttribute("categoria", categoria);
            request.setAttribute("texto", texto);
            doGet(request, response);
        }
    }


}
