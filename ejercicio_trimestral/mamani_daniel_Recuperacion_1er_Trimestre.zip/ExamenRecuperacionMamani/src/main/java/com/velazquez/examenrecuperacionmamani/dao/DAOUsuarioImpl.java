package com.velazquez.examenrecuperacionmamani.dao;

import com.velazquez.examenrecuperacionmamani.bd.PoolDB;
import com.velazquez.examenrecuperacionmamani.model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOUsuarioImpl implements DAOUsuario {
    public DAOUsuarioImpl() {
    }

    @Override
    public Usuario getUsuario(String nombre) {
        Usuario usuario = null;
        Connection con = null;

        try {
            String sql = "SELECT * FROM usuarios WHERE email=?";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, nombre);

            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                usuario = new Usuario();
                usuario.setUsuario(rs.getString("usuario"));
                usuario.setPassword(rs.getString("password"));
                usuario.setEmail(rs.getString("email"));
                usuario.setRole(rs.getString("role"));
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
        return usuario;
    }

    @Override
    public boolean registerUsuario(Usuario usuario) {
        int resultado = 0;
        Connection con = null;

        try {
            String sql = "INSERT INTO usuarios VALUES(?,?,?,?)";
            con = new PoolDB().getConnection();
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, usuario.getUsuario());
            statement.setString(2, usuario.getPassword());
            statement.setString(3, usuario.getEmail());
            statement.setString(4, usuario.getRole());

            resultado = statement.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }
        return (resultado != 0);
    }
}
