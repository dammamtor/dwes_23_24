package com.example.ejerciciotrimestralservidor_dmt.dao;

import com.example.ejerciciotrimestralservidor_dmt.model.Usuario;

public interface DAOUsuario {
    public Usuario getUsuario(String nombre);

    public boolean registerUsuario(Usuario usuario);
}
