package com.example.ejerciciotrimestralservidor_dmt.dao;

import com.example.ejerciciotrimestralservidor_dmt.bd.PoolDB;
import com.example.ejerciciotrimestralservidor_dmt.model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DAOUsuarioImpl implements DAOUsuario {

    private static final Logger logger = LoggerFactory.getLogger(DAOUsuarioImpl.class);

    public DAOUsuarioImpl() {
    }

    @Override
    public Usuario getUsuario(String email) {
        Usuario usuario = null;

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "SELECT * FROM usuarios WHERE email=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, email);

                try (ResultSet rs = statement.executeQuery()) {
                    // Como el campo de búsqueda es la clave solo debería obtener un resultado
                    // si no es así estaremos machacando cada vez el valor de customer y
                    while (rs.next()) {
                        usuario = new Usuario();
                        usuario.setUsuario(rs.getString("usuario"));
                        usuario.setPassword(rs.getString("password"));
                        usuario.setEmail(rs.getString("email"));
                        usuario.setRole(rs.getString("role"));
                    }
                }
            }
        } catch (SQLException ex) {
            logger.error("Error obtaining user: {}", ex.getMessage(), ex);
        }
        return usuario;
    }

    @Override
    public boolean registerUsuario(Usuario usuario) {
        int resultado = 0;

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "INSERT INTO usuarios VALUES(?,?,?,?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, usuario.getUsuario());
                statement.setString(2, usuario.getPassword());
                statement.setString(3, usuario.getEmail());
                statement.setString(4, usuario.getRole());

                resultado = statement.executeUpdate();
            }
        } catch (SQLException ex) {
            logger.error("Error registering user: {}", ex.getMessage(), ex);
        }
        return (resultado != 0);
    }
}