package com.example.ejerciciotrimestralservidor_dmt.dao;

import com.example.ejerciciotrimestralservidor_dmt.bd.PoolDB;
import com.example.ejerciciotrimestralservidor_dmt.model.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
public class DAOProductImpl implements DAOProduct{
    @Override
    public Product getProduct(String productName) {
        Product product = null;

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "SELECT * FROM products WHERE  productName=?";

            try(PreparedStatement statement = connection.prepareStatement(sql)){
                statement.setString(1, productName);

                try (ResultSet rs = statement.executeQuery()){
                    while (rs.next()) {
                        product = new Product();
                        product.setProductName(rs.getString("productName"));
                        product.setProductCode(rs.getString("productCode"));
                        product.setProductLine(rs.getString("productLine"));
                        product.setProductScale(rs.getString("productScale"));
                        product.setProductVendor(rs.getString("productVendor"));
                        product.setProductDescription(rs.getString("productDescription"));
                        product.setQuantityInStock(rs.getInt("quantityInStock"));
                        product.setBuyPrice(rs.getDouble("buyPrice"));
                        product.setMsrp(rs.getDouble("MSRP"));
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return product;

    }

    @Override
    public ArrayList<Product> getProductSearch(String searchTerm) {
        ArrayList<Product> products = new ArrayList<>();

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "SELECT * FROM products WHERE productName LIKE ? OR productLine LIKE ?";

            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, "%" + searchTerm + "%");
                statement.setString(2, "%" + searchTerm + "%");

                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        Product product = new Product();
                        product.setProductName(rs.getString("productName"));
                        product.setProductCode(rs.getString("productCode"));
                        product.setProductLine(rs.getString("productLine"));
                        product.setProductScale(rs.getString("productScale"));
                        product.setProductVendor(rs.getString("productVendor"));
                        product.setProductDescription(rs.getString("productDescription"));
                        product.setQuantityInStock(rs.getInt("quantityInStock"));
                        product.setBuyPrice(rs.getDouble("buyPrice"));
                        product.setMsrp(rs.getDouble("MSRP"));

                        products.add(product);
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return products;
    }


    public String echo() {
        return "echo";
    }

    @Override
    public Product getProductByCode(String code) {
        Product product = null;

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "SELECT * FROM products WHERE productCode=?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, code);

                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        product = new Product();
                        product.setProductName(rs.getString("productName"));
                        product.setProductCode(rs.getString("productCode"));
                        product.setProductLine(rs.getString("productLine"));
                        product.setProductScale(rs.getString("productScale"));
                        product.setProductVendor(rs.getString("productVendor"));
                        product.setProductDescription(rs.getString("productDescription"));
                        product.setQuantityInStock(rs.getInt("quantityInStock"));
                        product.setBuyPrice(rs.getDouble("buyPrice"));
                        product.setMsrp(rs.getDouble("MSRP"));
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return product;
    }
    public ArrayList<Product> getProductsByProductLine(String productLine) {
        ArrayList<Product> products = new ArrayList<>();

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "SELECT * FROM products WHERE productLine = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, productLine);

                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        Product product = new Product();
                        product.setProductName(rs.getString("productName"));
                        product.setProductCode(rs.getString("productCode"));
                        product.setProductLine(rs.getString("productLine"));
                        product.setProductScale(rs.getString("productScale"));
                        product.setProductVendor(rs.getString("productVendor"));
                        product.setProductDescription(rs.getString("productDescription"));
                        product.setQuantityInStock(rs.getInt("quantityInStock"));
                        product.setBuyPrice(rs.getDouble("buyPrice"));
                        product.setMsrp(rs.getDouble("MSRP"));

                        products.add(product);
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return products;
    }
}
