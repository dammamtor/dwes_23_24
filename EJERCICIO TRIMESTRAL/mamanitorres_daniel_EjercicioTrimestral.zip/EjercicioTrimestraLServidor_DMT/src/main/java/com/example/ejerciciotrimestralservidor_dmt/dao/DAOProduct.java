package com.example.ejerciciotrimestralservidor_dmt.dao;


import com.example.ejerciciotrimestralservidor_dmt.model.Product;

import java.util.ArrayList;

public interface DAOProduct {
    public Product getProduct(String productName);

    public Product getProductByCode(String code);

    public ArrayList<Product> getProductSearch(String searchTerm);

    public ArrayList<Product> getProductsByProductLine(String productLine);
}
