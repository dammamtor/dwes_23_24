package com.example.ejerciciotrimestralservidor_dmt.controller;

import com.example.ejerciciotrimestralservidor_dmt.dao.DAOProductImpl;
import com.example.ejerciciotrimestralservidor_dmt.model.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;

public class MostrarProductosServlet  extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(MostrarProductosServlet.class);

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Obtener el productLine de la sesión
        String productLine = (String) request.getSession().getAttribute("productLine");

        // Verificar si el productLine está presente
        if (productLine != null) {
            // Obtener la lista de productos para el productLine
            DAOProductImpl daoProduct = new DAOProductImpl();
            ArrayList<Product> productList = daoProduct.getProductsByProductLine(productLine);

            // Agregar la lista de productos al request para ser utilizada en la JSP
            request.setAttribute("productList", productList);
        }

        // Redirigir a tu JSP existente
        request.getRequestDispatcher("/WEB-INF/view/mostrarProductos.jsp").forward(request, response);
    }
}
