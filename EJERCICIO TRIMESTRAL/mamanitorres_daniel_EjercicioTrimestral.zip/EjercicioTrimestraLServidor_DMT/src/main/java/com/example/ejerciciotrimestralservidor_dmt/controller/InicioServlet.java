package com.example.ejerciciotrimestralservidor_dmt.controller;

import com.example.ejerciciotrimestralservidor_dmt.dao.DAOProductImpl;
import com.example.ejerciciotrimestralservidor_dmt.dao.DAOProductLineImpl;
import com.example.ejerciciotrimestralservidor_dmt.model.Product;
import com.example.ejerciciotrimestralservidor_dmt.model.ProductLine;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class InicioServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(InicioServlet.class);

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("SERVLET DE INICIO. CATEGORIAS DISPONIBLES");
        request.getRequestDispatcher("/WEB-INF/view/inicioUsuario.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        logger.info("ESTAS EN EL POST DE INICIO SERVLET");

        // Recogemos los datos del formulario
        String productLineSeleccionado = request.getParameter("categoria");

        logger.info("Categoria seleccionada: {}", productLineSeleccionado);

        if (productLineSeleccionado != null) {
            request.getSession().setAttribute("categoriaSeleccionada", productLineSeleccionado);

            DAOProductLineImpl dao = new DAOProductLineImpl();
            ProductLine productLine = dao.getProductLine(productLineSeleccionado);

            logger.info("Product Line Nombre: " + productLine.getProductLine());

            response.sendRedirect(request.getContextPath() + "/mostrarProductos.jsp");
        }
    }

}
