package com.example.ejerciciotrimestralservidor_dmt.dao;

import com.example.ejerciciotrimestralservidor_dmt.model.ProductLine;

import java.util.ArrayList;

public interface DAOProductLine {
    public ProductLine getProductLine(String productLine);

    public ArrayList<ProductLine> getAll();

}
