package com.example.ejerciciotrimestralservidor_dmt.controller;

import java.io.*;

import com.example.ejerciciotrimestralservidor_dmt.dao.DAOUsuarioImpl;
import com.example.ejerciciotrimestralservidor_dmt.model.Usuario;
import com.example.ejerciciotrimestralservidor_dmt.utils.PasswordHashGenerator;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.ServletException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;

//@WebServlet(name = "LoginServlet", value = "/hello-servlet")
public class LoginServlet extends HttpServlet {
    static final Logger logger = LoggerFactory.getLogger(LoginServlet.class);
    private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/view/index.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Comprobamos si tenemos los datos de la petición del formulario
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        DAOUsuarioImpl dao = new DAOUsuarioImpl();

        Usuario user = dao.getUsuario(email);

        logger.info("Usuario encontrado: " + user.getUsuario());
        logger.info("Correo encontrado: " + user.getEmail());
        logger.info("Password DB: " + user.getPassword());
        logger.info("Password Request: " + password);
        /*
        para usuario normal: dammamtor, danieltorres41618@gmail.com, SeruGiran!69
         */
        if (email != null && password != null) {

            if (user != null) {
                logger.info("Usuario encontrado: " + user.getUsuario());
                logger.info("Correo encontrado: " + user.getEmail());
                logger.info("Rol encontrado: " + user.getRole());
                logger.info("Password DB: " + user.getPassword());
                logger.info("Password Request: " + password);
                if (PasswordHashGenerator.checkPassword(password, user.getPassword())) {

                    HttpSession sesion = request.getSession();

                    sesion.setAttribute("usuario", user.getUsuario());
                    sesion.setAttribute("email", user.getEmail());
                    sesion.setAttribute("role", user.getRole());

//                    if ("admin".equals(user.getRole())) {
//                        response.sendRedirect("Admin/"); // Cambia la URL de redirección si es necesario
//                    } else {
//                        response.sendRedirect(request.getContextPath() + "/Inicio"); // Redirige a InicioServlet
//                    }
                    response.sendRedirect(request.getContextPath() + "/Inicio"); // Redirige a InicioServlet
                } else {
                    request.setAttribute("error", "login inválido");
                    doGet(request, response);
                    return;
                }
            } else {
                request.setAttribute("error", "Usuario no existente");
                doGet(request, response);
            }
        }
    }
}