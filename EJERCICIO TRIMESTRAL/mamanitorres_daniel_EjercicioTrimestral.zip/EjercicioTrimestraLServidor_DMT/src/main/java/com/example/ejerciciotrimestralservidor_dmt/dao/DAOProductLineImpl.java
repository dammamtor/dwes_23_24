package com.example.ejerciciotrimestralservidor_dmt.dao;

import com.example.ejerciciotrimestralservidor_dmt.bd.PoolDB;
import com.example.ejerciciotrimestralservidor_dmt.model.ProductLine;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DAOProductLineImpl implements DAOProductLine{
    static final Logger logger = LoggerFactory.getLogger(DAOProductLineImpl.class);

    public DAOProductLineImpl() {
    }
    @Override
    public ProductLine getProductLine(String productLine) {
        ProductLine categoria = null;

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "SELECT * FROM productlines WHERE productLine = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, productLine);
                try (ResultSet rs = statement.executeQuery()) {
                    // Como el campo de búsqueda es la clave solo debería obtener un resultado
                    // si no es así estaremos machacando cada vez el valor de productLine
                    while (rs.next()) {
                        categoria = new ProductLine();

                        categoria.setProductLine(rs.getString("productLine"));
                        categoria.setTextDescription(rs.getString("textDescription"));
                        categoria.setHtmlDescription(rs.getString("htmlDescription"));
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            logger.error(Arrays.toString(e.getStackTrace()));
        }

        return categoria;
    }


    @Override
    public ArrayList<ProductLine> getAll() {
        ArrayList<ProductLine> categoriasList = new ArrayList<>();

        try (Connection connection = new PoolDB().getConnection()) {
            String sql = "SELECT * FROM productlines";
            try (PreparedStatement statement = connection.prepareStatement(sql);
                 ResultSet rs = statement.executeQuery()) {

                while (rs.next()) {
                    ProductLine categoria = new ProductLine();
                    categoria.setProductLine(rs.getString("productLine"));
                    categoria.setTextDescription(rs.getString("textDescription"));
                    categoria.setHtmlDescription(rs.getString("htmlDescription"));

                    categoriasList.add(categoria);
                }
            }
        } catch (SQLException e) {
            logger.error(e.getMessage());
            logger.error(Arrays.toString(e.getStackTrace()));
        }

        return categoriasList;
    }

}
