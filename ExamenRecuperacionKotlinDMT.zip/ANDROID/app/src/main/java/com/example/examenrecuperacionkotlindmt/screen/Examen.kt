package com.example.examenrecuperacionkotlindmt.screen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.examenrecuperacionkotlindmt.data.Asignatura
import com.example.examenrecuperacionkotlindmt.data.DataSource


class Examen {
    @Composable
    fun examenScreen(
        modifier: Modifier = Modifier,
        asignaturas: ArrayList<Asignatura> = DataSource.loterias
    ) {
        var textoAccion: MutableState<String> = remember {
            mutableStateOf("No has hecho ninguna acción")
        }
        var textoResumen: MutableState<String> = remember {
            mutableStateOf("No hay nada que mostrar")
        }
        var textoEditor: MutableState<String> = remember {
            mutableStateOf("")
        }
        var horasContratadas: MutableState<Int> = remember {
            mutableStateOf(0)
        }
        var nombreAsignatura: MutableState<String> = remember {
            mutableStateOf("No has hecho ninguna acción")
        }

        Column {
            Box(
                modifier = modifier
                    .fillMaxWidth()
                    .background(Color.Gray)
            ) {
                Text(
                    text = "Bienvenido a la academia de DMT",
                    modifier = Modifier
                        .padding(start = 10.dp, top = 20.dp)
                )
            }

            asignaturasScroll(
                modifier = modifier,
                asignaturas = asignaturas,
                textoAccion = textoAccion,
                textoEditor = textoEditor,
                textoResumen = textoResumen,
                horasContratadas = horasContratadas
            )
            textEditorExamen(textoEditor = textoEditor)
            textoAbajoMostrar(
                textoEditor = textoEditor,
                textoAccion = textoAccion,
                textoResumen = textoResumen
            )
        }
    }

    @Composable
    fun asignaturasScroll(
        modifier: Modifier,
        asignaturas: ArrayList<Asignatura>,
        textoEditor: MutableState<String>,
        textoAccion: MutableState<String>,
        textoResumen: MutableState<String>,
        horasContratadas: MutableState<Int>,
    ) {
        LazyVerticalGrid(
            GridCells.Fixed(2),
            modifier = modifier
                .height(350.dp)
        ) {
            items(asignaturas) { asignatura ->
                Card(
                    modifier = Modifier
                        .padding(8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = "Asig. ${asignatura.nombre}",
                            modifier = Modifier
                                .background(Color.Yellow)
                                .padding(18.dp)
                                .fillMaxWidth()
                        )
                        Text(
                            text = "Euro/hora: ${asignatura.precioHora}",
                            modifier = Modifier
                                .background(Color.Cyan)
                                .padding(18.dp)
                                .fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.LightGray)
                                .padding(16.dp)
                                .align(Alignment.CenterHorizontally)
                        ) {
                            Button(onClick = {

                                val horasAContratar =
                                    if (textoEditor.value.isNotBlank()) {
                                        textoEditor.value.toInt()
                                    } else {
                                        1
                                    }
                                horasContratadas.value += horasAContratar
                                textoAccion.value =
                                    "Se han añadido $horasAContratar horas de ${asignatura.nombre} con precio ${asignatura.precioHora}"
                                textoResumen.value =
                                    "Asig: ${asignatura.nombre} precio hora ${asignatura.precioHora}total horas : ${horasContratadas.value}"
                            }) {
                                Text(text = "+")
                            }


                            Button(onClick = {
                                val horasARestar =
                                    if (textoEditor.value.isNotBlank()) {
                                        textoEditor.value.toInt()
                                    } else {
                                        1
                                    }

                                var horasRestantes = horasContratadas.value - horasARestar

                                if (horasRestantes < 0) {
                                    horasRestantes = 0
                                }

                                var horasRestadas = horasContratadas.value - horasRestantes
                                horasContratadas.value = horasRestantes
                                textoAccion.value =
                                    "Se han restado $horasRestadas horas de ${asignatura.nombre} con precio ${asignatura.precioHora}"
                                textoResumen.value =
                                    "Asig: ${asignatura.nombre} precio hora ${asignatura.precioHora} total horas : ${horasContratadas.value}"
                            }) {
                                Text(text = "-")
                            }
                        }
                    }
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun textEditorExamen(
        textoEditor: MutableState<String>
    ) {
        TextField(
            value = textoEditor.value,
            label = { Text(text = "Horas a contratar o a eliminar") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            onValueChange = { textoEditor.value = it })


    }

    @Composable
    fun textoAbajoMostrar(
        textoEditor: MutableState<String>,
        textoAccion: MutableState<String>,
        textoResumen: MutableState<String>
    ) {
        Column(
            modifier = Modifier
                .background(Color.Magenta)
        ) {
            Text(
                text = "Ultima accion",
                modifier = Modifier
                    .fillMaxWidth()
            )
            Text(
                text = textoAccion.value,
                modifier = Modifier
                    .fillMaxWidth()
            )


        }
        Column(
            modifier = Modifier
                .background(Color.Red)
        ) {
            Text(
                text = "Resumen",
                modifier = Modifier
                    .fillMaxWidth()
            )
            Text(
                text = textoResumen.value,
                modifier = Modifier
                    .fillMaxWidth()
            )


        }
    }

}