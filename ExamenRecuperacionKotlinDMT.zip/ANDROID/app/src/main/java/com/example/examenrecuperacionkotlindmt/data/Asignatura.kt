package com.example.examenrecuperacionkotlindmt.data

data class Asignatura (val nombre:String, val precioHora:Int)