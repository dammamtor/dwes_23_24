import model.Comments;
import model.Posts;
import model.Scoring;
import model.Users;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import services.CommentsService;
import services.PostsService;
import services.ScoringService;
import services.UsersService;
import services.impl.CommentsServiceImpl;
import services.impl.PostsServiceImpl;
import services.impl.ScoringServiceImpl;
import services.impl.UsersServiceImpl;

import java.util.Set;

public class Main {
    static final Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        logger.info("HORA DE COMENZAR LA TONTADA");
        Session session = HibernateUtils.getSessionFactory().openSession();

        UsersService usersService = new UsersServiceImpl(session);
        PostsService postsService = new PostsServiceImpl(session);
        CommentsService commentsService = new CommentsServiceImpl(session);
        ScoringService scoringService = new ScoringServiceImpl(session);

        logger.info("HORA DE CREAR LOS USUARIOS");
        Users users = new Users();
        users.setUserName("dammamtor");
        users.setPassword("XXXXX");
        users.setFirstName("Daniel");
        users.setLastName("Torres");
        users.setEmail("daniel@gmail.com");

        Users users1 = new Users();
        users1.setUserName("cobracule");
        users1.setPassword("ZZZZZ");
        users1.setFirstName("Lautaro");
        users1.setLastName("Del Campo");
        users1.setEmail("cobra-domado@gmail.com");

        logger.info("HORA DE CREAR LOS POSTS");
        Posts posts = new Posts();
        posts.setTitle("¿Se fue a la B, Boca Juniors?");

        Posts posts1 = new Posts();
        posts1.setTitle("¿Los dominicanos solo saben de beisbol?");

        Posts posts2 = new Posts();
        posts2.setTitle("¿Ganaran un mundial en su vida, los mexicanos?");

        Posts posts3 = new Posts();
        posts3.setTitle("¿El Barça tendrá nuevo DT?");

        Posts posts4 = new Posts();
        posts4.setTitle("Era mano lo de Vinicius en el ultimo partido");

        posts.setUsers(users);
        posts1.setUsers(users1);
        posts2.setUsers(users1);
        posts3.setUsers(users);
        posts4.setUsers(users1);

        logger.info("TOCA AGREGAR COMENTARIOS");
        Comments comments = new Comments();
        comments.setTitle("obvio, hace rato que se fueron");

        Comments comments1 = new Comments();
        comments1.setTitle("si obvio era mano");

        Comments comments2 = new Comments();
        comments2.setTitle("la concacaf esta muerta");

        usersService.insertNewUser(users);
        usersService.insertNewUser(users1);

        postsService.insertNewPost(posts);
        postsService.insertNewPost(posts1);
        postsService.insertNewPost(posts2);
        postsService.insertNewPost(posts3);
        postsService.insertNewPost(posts4);

        comments.setUsers(users1);
        comments.setPosts(posts);

        comments2.setUsers(users);
        comments2.setPosts(posts1);

        commentsService.insertNewComment(comments);
        commentsService.insertNewComment(comments1);
        commentsService.insertNewComment(comments2);

        logger.info("HORA DE CREAR VALORACIONES");
        Scoring scoring1 = new Scoring();
        scoring1.setUser(users);
        scoring1.setPost(posts);
        scoring1.setScore(4.5);

        Scoring scoring2 = new Scoring();
        scoring2.setUser(users1);
        scoring2.setPost(posts1);
        scoring2.setScore(3.8);
        Scoring scoring3 = new Scoring();
        scoring3.setUser(users);
        scoring3.setPost(posts2);
        scoring3.setScore(2.5);

        Scoring scoring4 = new Scoring();
        scoring4.setUser(users1);
        scoring4.setPost(posts3);
        scoring4.setScore(4.2);

        Scoring scoring5 = new Scoring();
        scoring5.setUser(users);
        scoring5.setPost(posts4);
        scoring5.setScore(3.0);

        Scoring scoring6 = new Scoring();
        scoring6.setUser(users1);
        scoring6.setPost(posts2);
        scoring6.setScore(3.5);

        Scoring scoring7 = new Scoring();
        scoring7.setUser(users);
        scoring7.setPost(posts1);
        scoring7.setScore(4.8);

        Scoring scoring8 = new Scoring();
        scoring8.setUser(users1);
        scoring8.setPost(posts4);
        scoring8.setScore(2.0);

        Scoring scoring9 = new Scoring();
        scoring9.setUser(users);
        scoring9.setPost(posts3);
        scoring9.setScore(4.0);

        Scoring scoring10 = new Scoring();
        scoring10.setUser(users1);
        scoring10.setPost(posts);
        scoring10.setScore(3.7);

        scoringService.insertNewScoring(scoring1);
        scoringService.insertNewScoring(scoring2);
        scoringService.insertNewScoring(scoring3);
        scoringService.insertNewScoring(scoring4);
        scoringService.insertNewScoring(scoring5);
        scoringService.insertNewScoring(scoring6);
        scoringService.insertNewScoring(scoring7);
        scoringService.insertNewScoring(scoring8);
        scoringService.insertNewScoring(scoring9);
        scoringService.insertNewScoring(scoring10);

        logger.info("TOCA USAR LAS FUNCIONES DE BUSQUEDA");
        logger.info("BUSCANDO USUARIO");
        usersService.getAllUsersFromNameOrEmail("dammamtor");
        logger.info("BUSCANDO COMENTARIOS");
        commentsService.searchByName("obvio");
        logger.info("Búsqueda de todos los títulos de los post creados por un usuario ");
        postsService.getTitlesFromUser(users);

        logger.info("Utilización de una función de modificiación para un usuario y una de borrado de un comentario");

        logger.info("HORA DE MODIFICAR UN USUARIO");
        System.out.println("Usuario antes de actualizar: " + users1);
        Users userE = users1;
        userE.setEmail("manaos@gmail.com");
        usersService.updateUser(userE);

        logger.info("HORA DE BORRAR UN COMENTARIO");
        Comments commentsX = new Comments();
        commentsX.setTitle("COMENTARIO DE PRUEBA");
        commentsService.insertNewComment(commentsX);
        System.out.println("hora de eliminar");
        commentsService.deleteComment(commentsX);
        session.close();
    }
}
