package model;
import dao.generic.Identifiable;
import jakarta.persistence.*;

import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table
public class Posts implements Identifiable {
    @Id
    @Column
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    @Column
    private String title;
    @Column
    private String content;
    @Column
    private Date date;
    @ManyToOne
    @JoinColumn(name = "idUsers")
    private Users users;
    @OneToMany(mappedBy = "posts",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private Set<Comments> comments = new HashSet<>();
    @OneToMany(mappedBy = "post",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private Set<Scoring> scorings = new HashSet<>();

    public Posts() {
    }

    public Posts(Long id, String title, String content, Date date, Users users) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.date = date;
        this.users = users;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    public Set<Comments> getComments() {
        return comments;
    }

    public void setComments(Set<Comments> comments) {
        this.comments = comments;
    }

    public Set<Scoring> getScorings() {
        return scorings;
    }

    public void setScorings(Set<Scoring> scorings) {
        this.scorings = scorings;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Posts posts = (Posts) o;
        return Objects.equals(id, posts.id) && Objects.equals(title, posts.title) && Objects.equals(content, posts.content) && Objects.equals(date, posts.date) && Objects.equals(users, posts.users) && Objects.equals(comments, posts.comments) && Objects.equals(scorings, posts.scorings);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, content, date, users, comments, scorings);
    }

    @Override
    public String toString() {
        return "Posts{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", date=" + date +
                ", users=" + users +
                '}';
    }
}
