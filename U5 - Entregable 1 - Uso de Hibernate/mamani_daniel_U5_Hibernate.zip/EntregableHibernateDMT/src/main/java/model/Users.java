package model;
import dao.generic.Identifiable;
import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Entity
@Table
public class Users implements Identifiable {
    @Id
    @Column
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    @Column
    private String userName;
    @Column
    private String firstName;
    @Column
    private String password;
    @Column
    private String lastName;
    @Column
    private String email;
    @OneToMany(mappedBy = "users",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private Set<Posts> posts = new HashSet<>();
    @OneToMany(mappedBy = "users",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private Set<Comments> comments = new HashSet<>();
    @OneToMany(mappedBy = "user",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private Set<Scoring> scorings = new HashSet<>();

    public Users() {
    }

    public Users(Long id, String userName, String firstName, String password, String lastName, String email) {
        this.id = id;
        this.userName = userName;
        this.firstName = firstName;
        this.password = password;
        this.lastName = lastName;
        this.email = email;
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Set<Posts> getPosts() {
        return posts;
    }

    public void setPosts(Set<Posts> posts) {
        this.posts = posts;
    }

    public Set<Comments> getComments() {
        return comments;
    }

    public void setComments(Set<Comments> comments) {
        this.comments = comments;
    }

    public Set<Scoring> getScorings() {
        return scorings;
    }

    public void setScorings(Set<Scoring> scorings) {
        this.scorings = scorings;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Users users = (Users) o;
        return Objects.equals(id, users.id) && Objects.equals(userName, users.userName) && Objects.equals(firstName, users.firstName) && Objects.equals(password, users.password) && Objects.equals(lastName, users.lastName) && Objects.equals(email, users.email) && Objects.equals(posts, users.posts) && Objects.equals(comments, users.comments) && Objects.equals(scorings, users.scorings);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, userName, firstName, password, lastName, email, posts, comments, scorings);
    }

    @Override
    public String toString() {
        return "Users{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", firstName='" + firstName + '\'' +
                ", password='" + password + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
