package model;
import dao.generic.Identifiable;
import jakarta.persistence.*;
@Entity
@IdClass(UsersPostsId.class)
public class Scoring implements Identifiable {
    @Id
    @ManyToOne
    @JoinColumn(name = "user_id", insertable = false, updatable = false )
    private Users user;

    @Id
    @ManyToOne
    @JoinColumn(name = "post_id", insertable = false, updatable = false )
    private Posts post;
    @Column
    private double score;

    public Scoring() {
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public Posts getPost() {
        return post;
    }

    public void setPost(Posts post) {
        this.post = post;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "Scoring{" +
                "user=" + user +
                ", post=" + post +
                ", score=" + score +
                '}';
    }

    @Override
    public Long getId() {
        return null;
    }
}
