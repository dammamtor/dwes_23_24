package dao;

import dao.generic.GenericDAO;
import model.Scoring;

public interface DAOScoring extends GenericDAO<Scoring> {
}
