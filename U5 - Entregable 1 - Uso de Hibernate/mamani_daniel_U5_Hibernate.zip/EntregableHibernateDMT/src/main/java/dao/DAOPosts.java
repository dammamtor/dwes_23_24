package dao;

import dao.generic.GenericDAO;
import model.Posts;
import model.Users;

import java.util.List;

public interface DAOPosts extends GenericDAO<Posts> {
    public List<String> getTitlesFromUser(final Users users);
}
