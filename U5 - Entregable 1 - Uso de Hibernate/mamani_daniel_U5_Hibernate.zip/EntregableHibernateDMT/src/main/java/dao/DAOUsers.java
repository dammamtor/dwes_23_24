package dao;

import dao.generic.GenericDAO;
import model.Users;

import java.util.List;

public interface DAOUsers extends GenericDAO<Users> {
    public List<Users> getAllUsersFromNameOrEmail(final String busqueda);
}
