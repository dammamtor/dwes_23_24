package dao.generic;

public interface Identifiable {
    Long getId();
}
