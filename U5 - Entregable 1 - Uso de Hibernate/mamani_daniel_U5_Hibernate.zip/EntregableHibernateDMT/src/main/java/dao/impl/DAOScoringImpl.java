package dao.impl;

import dao.DAOScoring;
import dao.generic.GenericDAOImpl;
import model.Scoring;
import org.hibernate.Session;

public class DAOScoringImpl extends GenericDAOImpl<Scoring> implements DAOScoring {
    public DAOScoringImpl(Session session) {
        super(session);
    }
}
