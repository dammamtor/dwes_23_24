package dao.impl;

import dao.DAOComments;
import dao.generic.GenericDAOImpl;
import model.Comments;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

public class DAOCommentsImpl extends GenericDAOImpl<Comments> implements DAOComments {
    private final Session session;

    public DAOCommentsImpl(Session session) {
        super(session);
        this.session = session;
    }

    @Override
    public List<Comments> searchByName(String comment) {
        if (!session.getTransaction().isActive()) {
            session.getTransaction().begin();
        }

        String hql = "FROM Comments c WHERE c.title LIKE :titulo";
        Query query = session.createQuery(hql);
        query.setParameter("titulo", "%" + comment + "%");
        List<Comments> commentsList = query.list();

        System.out.println("Resultado de búsqueda por comentarios: " + commentsList);

        if (!commentsList.isEmpty()) {
            return commentsList;
        } else {
            return null;
        }
    }

}
