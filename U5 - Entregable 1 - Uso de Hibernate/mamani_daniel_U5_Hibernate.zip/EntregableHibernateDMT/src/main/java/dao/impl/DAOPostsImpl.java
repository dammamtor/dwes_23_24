package dao.impl;

import dao.DAOPosts;
import dao.generic.GenericDAOImpl;
import model.Posts;
import model.Users;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

public class DAOPostsImpl extends GenericDAOImpl<Posts> implements DAOPosts {
    private final Session session;

    public DAOPostsImpl(Session session) {
        super(session);
        this.session = session;
    }

    @Override
    public List<String> getTitlesFromUser(Users users) {
        if (!session.getTransaction().isActive()) {
            session.getTransaction().begin();
        }
        String hql = "SELECT p.title FROM Posts p JOIN p.users u WHERE u.id = :userId";
        Query<String> query = session.createQuery(hql, String.class);
        query.setParameter("userId", users.getId());
        List<String> titlesList = query.list();

        System.out.println("Resultado de búsqueda por comentarios: " + titlesList);
        return titlesList;
    }

}
