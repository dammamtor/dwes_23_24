package dao.impl;

import dao.DAOUsers;
import dao.generic.GenericDAOImpl;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import model.Users;
import org.hibernate.Session;

import java.util.List;

public class DAOUsersImpl extends GenericDAOImpl<Users> implements DAOUsers {
    private final Session session;

    public DAOUsersImpl(Session session) {
        super(session);
        this.session = session;
    }

    @Override
    public List<Users> getAllUsersFromNameOrEmail(String busqueda) {
        if (!session.getTransaction().isActive()) {
            session.getTransaction().begin();
        }
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<Users> criteria = builder.createQuery(Users.class);
        Root<Users> root = criteria.from(Users.class);

        Predicate userNamePredicate = builder.equal(root.get("userName"), busqueda);
        Predicate userDescriptionPredicate = builder.equal(root.get("email"), busqueda);
        Predicate orPredicate = builder.or(userNamePredicate, userDescriptionPredicate);

        criteria.select(root);
        criteria.where(orPredicate);
        List<Users> resultados = session.createQuery(criteria).getResultList();

        // Imprimir los resultados en la consola
        System.out.println("Resultados de la búsqueda por nombre o descripción:");
        for (Users users : resultados) {
            System.out.println("ID: " + users.getId() + ", Username: " + users.getUserName() + ", Email: " + users.getEmail());
        }

        return resultados;
    }
}
