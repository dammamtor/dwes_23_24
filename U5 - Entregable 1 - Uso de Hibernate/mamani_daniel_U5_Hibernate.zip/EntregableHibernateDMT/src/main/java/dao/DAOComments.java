package dao;

import dao.generic.GenericDAO;
import model.Comments;

import java.util.List;

public interface DAOComments extends GenericDAO<Comments> {
    public List<Comments> searchByName(String comment);
}
