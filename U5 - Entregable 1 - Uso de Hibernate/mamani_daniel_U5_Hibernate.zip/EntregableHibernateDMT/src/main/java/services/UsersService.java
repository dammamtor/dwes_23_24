package services;

import model.Users;

import java.util.List;

public interface UsersService {
    public void insertNewUser(final Users users);

    public Users updateUser(final Users users);

    public void deleteUser(final Users users);

    public Users searchById(final Long userId);

    public List<Users> getAllUsersFromNameOrEmail(final String busqueda);

    public List<Users> searchAll();
}
