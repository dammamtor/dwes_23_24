package services;

import model.Comments;

import java.util.List;

public interface CommentsService {
    public void insertNewComment(final Comments comments);

    public Comments updateComment(final Comments comments);

    public void deleteComment(final Comments comments);

    public Comments searchById(final Long commentId);

    public List<Comments> searchByName(String comment);

    public List<Comments> searchAll();
}
