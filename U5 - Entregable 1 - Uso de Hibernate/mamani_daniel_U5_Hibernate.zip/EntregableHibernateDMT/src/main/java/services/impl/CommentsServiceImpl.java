package services.impl;

import dao.DAOComments;
import dao.impl.DAOCommentsImpl;
import model.Comments;
import org.hibernate.Session;
import services.CommentsService;

import java.util.List;

public class CommentsServiceImpl implements CommentsService {
    DAOComments daoComments;

    public CommentsServiceImpl(Session session) {
        daoComments = new DAOCommentsImpl(session);
    }
    @Override
    public void insertNewComment(Comments comments) {
        if (comments != null && comments.getId() == null) {
            daoComments.insert(comments);
        }
    }

    @Override
    public Comments updateComment(Comments comments) {
        Comments commentUpdated = null;
        if (comments != null && comments.getId() != null) {
            commentUpdated = daoComments.update(comments);
        }
        return commentUpdated;
    }

    @Override
    public void deleteComment(Comments comments) {
        if (comments != null && comments.getId() != null) {
            daoComments.delete(comments);
        }
    }

    @Override
    public Comments searchById(Long commentId) {
        if (commentId != null) {
            return daoComments.searchById(commentId);
        }
        return null;
    }

    @Override
    public List<Comments> searchByName(String comment) {
        if (comment != null) {
            return daoComments.searchByName(comment);
        }
        return null;
    }

    @Override
    public List<Comments> searchAll() {
        return daoComments.searchAll();
    }
}
