package services.impl;

import dao.DAOScoring;
import dao.DAOUsers;
import dao.impl.DAOScoringImpl;
import dao.impl.DAOUsersImpl;
import model.Scoring;
import model.Users;
import org.hibernate.Session;
import services.UsersService;

import java.util.List;

public class UsersServiceImpl implements UsersService {
    DAOUsers daoUsers;
    public UsersServiceImpl(Session session) {
        daoUsers = new DAOUsersImpl(session);
    }
    @Override
    public void insertNewUser(Users users) {
        if (users != null && users.getId() == null) {
            daoUsers.insert(users);
        }
    }

    @Override
    public Users updateUser(Users users) {
        Users usersUpdated = null;
        if (users != null && users.getId() != null) {
            usersUpdated = daoUsers.update(users);
        }
        return usersUpdated;
    }

    @Override
    public void deleteUser(Users users) {
        if (users != null && users.getId() != null) {
            daoUsers.delete(users);
        }
    }

    @Override
    public Users searchById(Long userId) {
        if (userId != null) {
            return daoUsers.searchById(userId);
        }
        return null;
    }

    @Override
    public List<Users> getAllUsersFromNameOrEmail(String busqueda) {
        if (busqueda != null && !busqueda.isEmpty()) {
            System.out.println("HAS LLEGADO AL GET DE USERS LIST");
            return daoUsers.getAllUsersFromNameOrEmail(busqueda);
        }
        return null;
    }

    @Override
    public List<Users> searchAll() {
        return daoUsers.searchAll();
    }
}
