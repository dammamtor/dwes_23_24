package services.impl;

import dao.DAOPosts;
import dao.DAOScoring;
import dao.impl.DAOPostsImpl;
import dao.impl.DAOScoringImpl;
import model.Posts;
import model.Scoring;
import org.hibernate.Session;
import services.ScoringService;

import java.util.List;

public class ScoringServiceImpl implements ScoringService {
    DAOScoring daoScoring;
    public ScoringServiceImpl(Session session) {
        daoScoring = new DAOScoringImpl(session);
    }
    @Override
    public void insertNewScoring(Scoring scoring) {
        if (scoring != null && scoring.getId() == null) {
            daoScoring.insert(scoring);
        }
    }

    @Override
    public Scoring updateScoring(Scoring scoring) {
        Scoring scoreUpdated = null;
        if (scoring != null && scoring.getId() != null) {
            scoreUpdated = daoScoring.update(scoring);
        }
        return scoreUpdated;
    }

    @Override
    public void deleteScoring(Scoring scoring) {
        if (scoring != null && scoring.getId() != null) {
            daoScoring.delete(scoring);
        }
    }

    @Override
    public Scoring searchById(Long scoringId) {
        if (scoringId != null) {
            return daoScoring.searchById(scoringId);
        }
        return null;
    }

    @Override
    public List<Scoring> searchAll() {
        return daoScoring.searchAll();
    }
}
