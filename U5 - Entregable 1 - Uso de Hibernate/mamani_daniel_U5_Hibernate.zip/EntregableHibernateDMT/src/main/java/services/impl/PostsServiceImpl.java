package services.impl;

import dao.DAOPosts;
import dao.impl.DAOPostsImpl;
import model.Comments;
import model.Posts;
import model.Users;
import org.hibernate.Session;
import services.PostsService;

import java.util.List;

public class PostsServiceImpl implements PostsService {
    DAOPosts daoPosts;
    public PostsServiceImpl(Session session) {
        daoPosts = new DAOPostsImpl(session);
    }
    @Override
    public void insertNewPost(Posts posts) {
        if (posts != null && posts.getId() == null) {
            daoPosts.insert(posts);
        }
    }

    @Override
    public Posts updatePost(Posts posts) {
        Posts postUpdated = null;
        if (posts != null && posts.getId() != null) {
            postUpdated = daoPosts.update(posts);
        }
        return postUpdated;
    }

    @Override
    public void deletePost(Posts posts) {
        if (posts != null && posts.getId() != null) {
            daoPosts.delete(posts);
        }
    }

    @Override
    public Posts searchById(Long postId) {
        if (postId != null) {
            return daoPosts.searchById(postId);
        }
        return null;
    }

    @Override
    public List<String> getTitlesFromUser(Users users) {
        return daoPosts.getTitlesFromUser(users);
    }

    @Override
    public List<Posts> searchAll() {
        return daoPosts.searchAll();
    }
}
