package services;

import model.Posts;
import model.Users;

import java.util.List;

public interface PostsService {
    public void insertNewPost(final Posts posts);

    public Posts updatePost(final Posts posts);

    public void deletePost(final Posts posts);

    public Posts searchById(final Long postId);

    public List<String> getTitlesFromUser(Users users);

    public List<Posts> searchAll();
}
