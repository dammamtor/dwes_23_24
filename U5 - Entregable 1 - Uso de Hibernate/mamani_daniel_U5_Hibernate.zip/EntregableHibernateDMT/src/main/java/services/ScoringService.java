package services;

import model.Scoring;

import java.util.List;

public interface ScoringService {
    public void insertNewScoring(final Scoring scoring);

    public Scoring updateScoring(final Scoring scoring);

    public void deleteScoring(final Scoring scoring);

    public Scoring searchById(final Long scoringId);

    public List<Scoring> searchAll();
}
