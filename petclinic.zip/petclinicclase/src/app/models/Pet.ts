export interface Pet {

}