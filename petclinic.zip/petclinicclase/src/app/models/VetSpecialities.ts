export interface VetSpecialities {
    id: number;
    name: string;
}