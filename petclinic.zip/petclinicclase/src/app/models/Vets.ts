import { VetSpecialities } from "./VetSpecialities";

export interface Vet {
    id: number;
    firstName: string;
    lastName: string;
    specialties: VetSpecialities[]
}