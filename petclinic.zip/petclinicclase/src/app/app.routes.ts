import { Routes } from '@angular/router';
import { OwnersComponent } from './components/owners/owners.component';
import { FormsComponent } from './components/forms/forms.component';
import { DetailOwnersComponent } from './components/detail-owners/detail-owners.component';
import { VetsComponent } from './components/vets/vets.component';
import { VetFormsComponent } from './components/vet-forms/vet-forms.component';
import { SpecialtiesComponent } from './components/specialties/specialties.component';
import { FormSpecComponent } from './components/form-spec/form-spec.component';

export const routes: Routes = [
    {
        path: "",
        component: OwnersComponent
    },
    {
        path: "forms/:id",
        component: FormsComponent
    },
    {
        path: "details-owners/:id",
        component: DetailOwnersComponent
    },
    {
        path: "vets",
        component: VetsComponent
    },
    {
        path: "vet-forms/:id",
        component: VetFormsComponent
    },
    {
        path: "specs",
        component: SpecialtiesComponent
    },
    {
        path: "spec-forms/:id",
        component: FormSpecComponent
    }
];
