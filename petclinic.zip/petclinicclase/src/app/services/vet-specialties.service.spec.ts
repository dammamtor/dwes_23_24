import { TestBed } from '@angular/core/testing';

import { VetSpecialtiesService } from './vet-specialties.service';

describe('VetSpecialtiesService', () => {
  let service: VetSpecialtiesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VetSpecialtiesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
