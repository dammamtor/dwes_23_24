import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Owner } from '../models/Owner';

@Injectable({
  providedIn: 'root'
})
export class OwnersService {
  private url: string = "http://localhost/ServicioWebApi/pet-clinic/servicios.php";

  constructor(private http: HttpClient) { }

  // Obtener lista de owners
  listarOwners() {
    let pa = JSON.stringify({
      accion: "ListarOwners"
    });
    return this.http.post<Owner[]>(this.url, pa);
  }

  // Obtener un owner por ID
  obtenerOwnerPorId(ownerId: number) {
    let pa = JSON.stringify({
      accion: "ObtenerOwnerId",
      id: ownerId
    });
    return this.http.post<Owner>(this.url, pa);
  }

  // Añadir un nuevo owner
  agregarOwner(owner: Owner) {
    let pa = JSON.stringify({
      accion: "AnadeOwner",
      owner: owner
    });
    return this.http.post<any>(this.url, pa);
  }

  // Actualizar un owner existente
  actualizarOwner(owner: Owner) {
    let pa = JSON.stringify({
      accion: "ModificaOwner",
      owner: owner
    });
    return this.http.post<any>(this.url, pa);
  }

  // Eliminar un owner por ID
  eliminarOwner(ownerId: number) {
    let pa = JSON.stringify({
      accion: "BorraOwner",
      id: ownerId,
      listado: "OK"
    });
    return this.http.post<any>(this.url, pa);
  }
}
