import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Vet } from '../models/Vets';
@Injectable({
  providedIn: 'root'
})
export class VetsService {

  private url: string = "http://localhost/ServicioWebApi/pet-clinic/servicios.php";

  constructor(private http: HttpClient) { }

  // Obtener lista de vets
  listarVets() {
    let pa = JSON.stringify({
      accion: "ListarVets"
    });
    return this.http.post<Vet[]>(this.url, pa);
  }

  // Añadir vets
  addVet(vet: Vet) {
    let body = JSON.stringify({ 
      accion: 'AnadeVet', 
      vet 
    });
    return this.http.post<any>(this.url, body);
  }

  // Conseguir vet por id
  getVetById(vetId: number){
    let body = JSON.stringify({ 
      accion: 'ObtenerVetId', 
      id: vetId 
    });
    return this.http.post<Vet>(this.url, body);
  }

  // UPDATE
  updateVet(vet: Vet){
    let body = JSON.stringify({ 
      accion: 'ModificaVet', 
      vet 
    });
    return this.http.post<any>(this.url, body);
  }

  // DELETE
  deleteVet(vetId: number) {
    let body = JSON.stringify({ 
      accion: 'BorraVet', 
      id: vetId,
    });
    return this.http.post<any>(this.url, body);
  }
}
