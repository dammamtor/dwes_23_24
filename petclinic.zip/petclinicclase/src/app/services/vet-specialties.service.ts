import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { VetSpecialities } from '../models/VetSpecialities';

@Injectable({
  providedIn: 'root'
})
export class VetSpecialtiesService {
  private url: string = "http://localhost/ServicioWebApi/pet-clinic/servicios.php";

  constructor(private http: HttpClient) { }

  listarVetSpecialties() {
    let pa = JSON.stringify({
      accion: "ListarSpecialties"
    });
    return this.http.post<VetSpecialities[]>(this.url, pa);
  }

  addSpec(spec: VetSpecialities) {
    let body = JSON.stringify({ 
      accion: 'AnadeSpecialty', 
      spec: spec 
    });
    return this.http.post<any>(this.url, body);
  }

  updateSpec(spec: VetSpecialities){
    let body = JSON.stringify({ 
      accion: 'ModificaSpecialty', 
      spec: spec 
    });
    return this.http.post<any>(this.url, body);
  }

  deleteSpec(specId: number) {
    let body = JSON.stringify({ 
      accion: 'BorraVet', 
      id: specId,
    });
    return this.http.post<any>(this.url, body);
  }
}
