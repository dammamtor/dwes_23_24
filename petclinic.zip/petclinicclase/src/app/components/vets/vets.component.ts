import { Component } from '@angular/core';
import { Vet } from '../../models/Vets';
import { VetsService } from '../../services/vets.service';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';


@Component({
  selector: 'app-vets',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './vets.component.html',
  styleUrl: './vets.component.css'
})
export class VetsComponent {
  public listaVets: Vet[] = []

  constructor(private peticion: VetsService, private ruta: Router) {
    this.peticion.listarVets().subscribe(datazos => {
      console.log("ESTAS EN EL CONSTRUCTOR: ", datazos);
      this.listaVets = datazos;
      console.log("LISTA DE VETS: ", this.listaVets);
      //this.pet = <Pet>{};
    })
  }
  nuevoVet() {
    this.ruta.navigate(["vet-forms", -1]);
  }
  modificarVet(id: number) {
    this.ruta.navigate(["vet-forms", id])
  }
  irOwners() {
    this.ruta.navigate([""])
  }
  borrarVet(vet: Vet) {
    console.log("LE DISTE A BORRAR PROPIETARIO");
    console.log("ID A BORRAR: ", vet.id);
    let id = vet.id;

    var confirmar = confirm("¿Está seguro de que desea borrar a " + vet.firstName + " " + vet.lastName + "?");
    if (confirmar) {

      this.peticion.deleteVet(id).subscribe(
        resp => {
          let re = <{ result: string }>resp;
          if (re.result == "OK") {
            this.listaVets = this.listaVets.filter(current_item => current_item.id !== id);
          } else {
            alert("Ha habido un error al borrar")
          }
        },
        error => {
          console.error("Error al intentar borrar el propietario: ", error);
        }
      );
    }
  }
}
