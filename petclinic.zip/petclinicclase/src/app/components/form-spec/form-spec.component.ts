import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-form-spec',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './form-spec.component.html',
  styleUrl: './form-spec.component.css'
})
export class FormSpecComponent {

}
