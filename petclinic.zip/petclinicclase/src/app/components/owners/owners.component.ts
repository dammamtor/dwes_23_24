import { Component } from '@angular/core';
import { OwnersService } from '../../services/owners.service';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';
import { Owner } from '../../models/Owner';

@Component({
  selector: 'app-owners',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './owners.component.html',
  styleUrl: './owners.component.css'
})
export class OwnersComponent {
  public listaOwner: Owner[] = [];

  constructor(private peticion: OwnersService, private ruta: Router) {
    this.peticion.listarOwners().subscribe(datazos => {
      console.log("ESTAS EN EL CONSTRUCTOR: ", datazos);
      this.listaOwner = datazos;
    })
  }
  nuevoOwner() {
    this.ruta.navigate(["forms", -1]);
  }
  modificarOwner(id: number) {
    this.ruta.navigate(["forms", id])
  }
  irVets(){
    this.ruta.navigate(["vets"])
  }
  irSpecs(){
    this.ruta.navigate(["specs"])
  }
  borrarOwner(id: number) {
    console.log("LE DISTE A BORRAR PROPIETARIO");
    console.log("ID A BORRAR: ", id);
    var confirmar = confirm("¿Está seguro de que desea borrar a " + id + "?");
    if (confirmar) {

      this.peticion.eliminarOwner(id).subscribe(
        result => {
          this.listaOwner = result;
          console.log(result);
        },
        error => {
          console.error("Error al intentar borrar el propietario: ", error);
        }
      );
    }
  }
}

