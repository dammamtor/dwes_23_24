import { Component } from '@angular/core';
import { Vet } from '../../models/Vets';
import { VetsService } from '../../services/vets.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { VetSpecialities } from '../../models/VetSpecialities';
import { VetSpecialtiesService } from '../../services/vet-specialties.service';

@Component({
  selector: 'app-vet-forms',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './vet-forms.component.html',
  styleUrl: './vet-forms.component.css'
})
export class VetFormsComponent {
  public vet: Vet;
  public textoBoton: string;
  public tituloForm: string;
  public specialties_list: VetSpecialities[] = [];

  constructor(private peticion: VetsService, private petSpec: VetSpecialtiesService, private ruta: Router, private rutaActiva: ActivatedRoute) {
    this.vet = {
      id: -1,
      firstName: "",
      lastName: "",
      specialties: []
    }

    this.petSpec.listarVetSpecialties().subscribe(datazos => {
      console.log("LISTA DE ESPECIALIDADES: ", datazos);
      this.specialties_list = datazos;
    })

    this.textoBoton = "AÑADIR"
    this.tituloForm = "Alta en el servicio"
  }
  ngOnInit(): void {
    const vetId = this.rutaActiva.snapshot.params["id"];
    console.log("TE LO COGE");
    console.log("vetId: ", vetId);

    if (vetId == -1) {
      console.log("Añadir Veterinario");
      this.textoBoton = "Agregar";
      this.tituloForm = "Añadir Veterinario"
    } else {
      this.textoBoton = "Modificar";
      this.tituloForm = "Modificar Veterinario"
      console.log("BOTON MODIFICAR AÑADIDO");

      this.peticion.getVetById(vetId).subscribe(
        (vet: Vet) => {
          console.log('Vet data:', vet);
          this.vet = vet;
        }, error => {
          console.error('Error obteniendo propietario:', error);
        }
      );
    }
  }

  onSubmit(vet: Vet): void {
    console.log("ESTA ES LA PERSONA QUE HA LLEGADO POR EL FORMULARIO: ", vet)

    if (this.vet.id === -1) {
      // Nuevo owner, llamar al servicio para agregarlo
      this.peticion.addVet(this.vet).subscribe(
        response => {
          console.log("Vet añadido exitosamente:", response);
          this.ruta.navigate(["vets"])
        },
        error => {
          console.error("Error al añadir owner:", error);
        }
      );
    } else {
      // Owner existente, llamar al servicio para actualizarlo
      this.peticion.updateVet(this.vet).subscribe(
        response => {
          console.log("Vet actualizado exitosamente:", response);
          this.ruta.navigate(["vets"])
        },
        error => {
          console.error("Error al actualizar owner:", error);
        }
      );
    }
  }

  onCancel(): void {
    this.ruta.navigate(["vets"])
  }
}
