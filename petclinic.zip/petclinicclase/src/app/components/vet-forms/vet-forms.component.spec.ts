import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VetFormsComponent } from './vet-forms.component';

describe('VetFormsComponent', () => {
  let component: VetFormsComponent;
  let fixture: ComponentFixture<VetFormsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VetFormsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VetFormsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
