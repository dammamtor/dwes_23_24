import { Component } from '@angular/core';
import { Owner } from '../../models/Owner';
import { OwnersService } from '../../services/owners.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-forms',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './forms.component.html',
  styleUrl: './forms.component.css'
})
export class FormsComponent {
  public owner: Owner;
  public textoBoton: string;
  public tituloForm: string;

  constructor(private peticion: OwnersService, private ruta: Router, private rutaActiva: ActivatedRoute) {
    this.owner = {
      id: -1,
      firstName: "",
      lastName: "",
      address: "",
      city: "",
      telephone: "",
      pets: []
    }
    this.textoBoton = "AÑADIR"
    this.tituloForm = "Alta en el servicio"
  }
  ngOnInit(): void {
    const ownerId = this.rutaActiva.snapshot.params["id"];
    console.log("TE LO COGE");
    console.log("ownerId: ", ownerId);

    if (ownerId == -1) {
      console.log("Añadir Propietario");
      this.textoBoton = "Agregar";
      this.tituloForm = "Añadir Propietario"
    } else {
      this.textoBoton = "Modificar";
      this.tituloForm = "Modificar Propietario"
      console.log("BOTON MODIFICAR AÑADIDO");

      this.peticion.obtenerOwnerPorId(ownerId).subscribe(
        (owner: Owner) => {
          console.log('Owner data:', owner);
          this.owner = owner;
        }, error => {
          console.error('Error obteniendo propietario:', error);
        }
      );
    }
  }

  onSubmit(owner: Owner): void {
    console.log("ESTA ES LA PERSONA QUE HA LLEGADO POR EL FORMULARIO: ", owner)

    if (this.owner.id === -1) {
      // Nuevo owner, llamar al servicio para agregarlo
      this.peticion.agregarOwner(this.owner).subscribe(
        response => {
          console.log("Owner añadido exitosamente:", response);
          this.ruta.navigate([""])
        },
        error => {
          console.error("Error al añadir owner:", error);
        }
      );
    } else {
      // Owner existente, llamar al servicio para actualizarlo
      this.peticion.actualizarOwner(this.owner).subscribe(
        response => {
          console.log("Owner actualizado exitosamente:", response);
          this.ruta.navigate([""])
        },
        error => {
          console.error("Error al actualizar owner:", error);
        }
      );
    }
  }

  onCancel(): void {
    this.ruta.navigate([""])
  }
}
