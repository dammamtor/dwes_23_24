import { Component } from '@angular/core';
import { Owner } from '../../models/Owner';
import { OwnersService } from '../../services/owners.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detail-owners',
  standalone: true,
  imports: [],
  templateUrl: './detail-owners.component.html',
  styleUrl: './detail-owners.component.css'
})
export class DetailOwnersComponent {
  public owner: Owner;

  constructor(
    private peticion: OwnersService,
    private router: Router,
    private rutaActiva: ActivatedRoute
  ) {
    this.owner = {
      id: -1,
      firstName: "",
      lastName: "",
      address: "",
      city: "",
      telephone: "",
      pets: []
    }
  }

  ngOnInit(): void {
    const ownerId = this.rutaActiva.snapshot.params["id"];

    this.peticion.obtenerOwnerPorId(ownerId).subscribe(
      (owner: Owner) => {
        this.owner = owner;
      },
      error => {
        console.error('Error obteniendo propietario:', error);
      }
    );
  }

  volverAListado(): void {
    // Navegar a la ruta raíz cuando se hace clic en el botón Volver
    this.router.navigate(['/']);
  }
}
