import { Component } from '@angular/core';
import { VetSpecialities } from '../../models/VetSpecialities';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';
import { VetSpecialtiesService } from '../../services/vet-specialties.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-specialties',
  standalone: true,
  imports: [RouterLink, FormsModule],
  templateUrl: './specialties.component.html',
  styleUrl: './specialties.component.css'
})
export class SpecialtiesComponent {
  public listaSpec: VetSpecialities[] = [];

  constructor(private peticion: VetSpecialtiesService, private ruta: Router) {
    this.peticion.listarVetSpecialties().subscribe(datazos => {
      console.log("ESTAS EN EL CONSTRUCTOR: ", datazos);
      this.listaSpec = datazos;
    })
  }
  nuevoSpec() {
    this.ruta.navigate(["spec-forms", -1]);
  }
  modificarSpec(spec: VetSpecialities) {
    console.log("TOMA SPEC: ", spec);
    this.peticion.updateSpec(spec).subscribe(
      resp => {
        let re = <{ result: string }>resp;
        if (re.result === "OK") {
          console.log("Especialidad actualizada con éxito");
        } else {
          alert("Ha habido un error al actualizar la especialidad");
        }
      },
      error => {
        console.error("Error al intentar actualizar la especialidad: ", error);
      }
    );
  }
  
  irHome() {
    this.ruta.navigate([""])
  }
  irSpecs() {
    this.ruta.navigate(["specs"])
  }
  borrarSpec(spec: VetSpecialities) {
    console.log("LE DISTE A BORRAR SPEC");
    console.log("ID A BORRAR: ", spec.id);
    let id = spec.id;

    var confirmar = confirm("¿Está seguro de que desea borrar a " + spec.name + "?");
    if (confirmar) {

      this.peticion.deleteSpec(id).subscribe(
        resp => {
          let re = <{ result: string }>resp;
          if (re.result == "OK") {
            this.listaSpec = this.listaSpec.filter(current_item => current_item.id !== id);
          } else {
            alert("Ha habido un error al borrar")
          }
        },
        error => {
          console.error("Error al intentar borrar el propietario: ", error);
        }
      );
    }
  }
}
